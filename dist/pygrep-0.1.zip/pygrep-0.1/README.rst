PyGrep
--------

To use (with caution), simply do::

    >>> import pygrep
    >>> print pygrep.grep('expression', 'path/to/file')