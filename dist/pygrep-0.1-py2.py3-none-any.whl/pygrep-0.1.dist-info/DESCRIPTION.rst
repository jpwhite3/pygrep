A pure Python implementation of the Unix tool GREP


